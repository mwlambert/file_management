from setuptools import setup, find_packages

setup(
    name='file_management',
    version='0.1',
    packages=['file_management'],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    install_requires=['tkinter'],
)